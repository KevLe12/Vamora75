# Vamora75 mechanical files

All parts share one coordinate system (STEP/STL, mm): X runs left to right along the front edge,
Y runs toward the rear, and Z points up from the desk. The case sits at its 6° typing angle.
The internal design frame (plate-parallel) is described in `Source/vamora_mech.py`.

| File | Contents |
|---|---|
| `Vamora75_assembly.step` | Case, gaskets, plate, plate foam, PCBA (KiCad export with all parts), case foam, switch and keycap envelopes. Coloured and instanced (7.5 MB). |
| `Vamora75_PCBA.step` | The PCB with every component, exported by KiCad. Origin is the PCB's front-left corner, board bottom at z = 0. |
| `Case/Vamora75_case_top.*`, `Case/Vamora75_case_bottom.*` | One-piece case parts |
| `Case/print_split/*_L/_R.*` | The same parts split for 250 x 210 mm beds (staggered seams, dowel holes) |
| `Plate/Vamora75_plate_FR4[_flexcut].dxf/.step/.stl` | Plate outline and openings (the DXF has OUTLINE, CUTOUTS and FLEX layers) |
| `Soft/*.dxf` | Gaskets (16), case foam (3 mm), plate foam (3.5 mm) |
| `key_positions.csv` | Every key: label, size, matrix, switch/diode refs, PCB and CAD coordinates, stabiliser spacing |
| `build/` | World-frame meshes used by `Source/render_previews.py` (intermediate files) |

Key numbers (from `validation/mechanical.json`):

* Footprint 358.6 x 156.7 mm. Height 21.0 mm at the front and 37.1 mm at the rear. Typing angle 6°.
* Mount: 8 plate tabs (20 x 5.5 mm), 16 gaskets (20 x 4.5 x 2.0 mm) set to 1.6 mm (20 %).
  Tab pockets have 0.5 mm clearance. The PCB and plate have 1.0 mm clearance to every wall.
* Fasteners: 8 M3 x 8 ISO 4762 screws from below, into M3 x 4 heat-set inserts (4.0 mm holes) in the top case.
* USB-C tunnel: 14.0 x 8.0 mm, R3.5, centred on J1. It passes a USB-IF maximum overmould (12.35 x 6.5 mm)
  with 0.8 mm to spare.
* BOOT pin-hole: 2.2 mm, through the floor under SW90.
* 12 interference checks run on every rebuild. Every overlap volume is 0 mm³, including keycaps
  pressed fully down (4 mm), the switches against the top case, and the gaskets against the plate and case.
