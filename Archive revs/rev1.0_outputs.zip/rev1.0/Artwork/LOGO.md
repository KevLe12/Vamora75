# The Vamora badge

![Vamora badge](Vamora75_badge_color.png)

## Idea

**One keycap, one star, three homes.**

* **The keycap** is the product. It is seen from above, and its rounded square also reads as a seal
  or stamp: a mark of the people who made the board.
* **The five-pointed star** is a shape all three flags share. It is the gold star of Việt Nam, the
  fifty stars of the United States, and the pentagram of Morocco.
* **The over-under weave** inside the star is the interlaced pentagram on the Moroccan flag, the
  Seal of Solomon (خاتم سليمان), which also appears in zellige strapwork. The weave is strictly
  alternating (over, under, over…) at all five crossings, and it is cut as thin lines, so the star
  still prints as one solid shape on silkscreen or in an engraving.
* **VΛMORΛ75**: the A's have no crossbar, so they repeat the star's points. The letters are
  geometric monoline shapes drawn for this project.
* **VIỆT NAM · USA · المغرب**: each country is named in its own language and script. The
  Vietnamese is set with its full diacritics, and the Arabic (*al-Maghrib*, "Morocco") is shaped
  with HarfBuzz so its letters join correctly.
* One way to read the name: **V**(iệt Nam) · **AM**(erica) · **MOR**(occo) → VAMORA.

## Colours

| Role | Hex | Meaning |
|---|---|---|
| Keycap body | navy `#0f2340` | USA |
| Keycap top | red `#c1272d` | the red that all three flags share |
| Star | gold `#f2c230` | Việt Nam's gold star |
| Interlace | green `#006233` | Morocco's green pentagram |
| Text | ink `#15171c` / paper `#f4f1ea` | |
| Metal accents | brass `#d4a640` | engraving fill, ENIG |

In the tagline, VIỆT NAM is red, USA is navy and المغرب is green.

## Where it is used

| Place | Size | Process |
|---|---|---|
| PCB bottom, left of the space socket (as seen from below) | 27 mm badge | White silkscreen, lines of 0.18 mm or more |
| PCB bottom | poem, credits in three languages, build info | Silkscreen |
| Plate, in the Esc-F1 gap and the F12-Del gap | 14 mm emblem + wordmark | Bare copper under a mask opening (gold with ENIG) |
| Case bottom | 98 mm badge | 0.6 mm engraving, 0.8 mm minimum feature (FDM-safe); can be paint-filled |

## Files

| File | Use |
|---|---|
| `Vamora75_badge_color.svg/.png` | Full-colour badge on light backgrounds |
| `Vamora75_badge_color_dark.svg/.png` | Full-colour badge on dark backgrounds |
| `Vamora75_badge_mono_black` / `_white` | One-colour badge (silkscreen, stickers, laser) |
| `Vamora75_emblem_color` / `_mono` | Keycap emblem alone (favicons, keycap legends, small marks) |
| `Vamora75_wordmark.svg/.png` | VΛMORΛ75 alone |
| `Vamora75_badge_engrave.dxf`, `Vamora75_emblem_engrave.dxf` | Closed outlines in mm for CNC, laser and engraving |
| `Vamora75_brand_sheet.png` | One-page overview |

## Rules

* Leave clear space of at least one star-point height on every side.
* Minimum sizes: badge 24 mm wide on silkscreen, 40 mm for CNC/laser, 80 mm for FDM engraving. Below
  those sizes, use the emblem alone.
* Do not recolour individual star segments, stretch the mark, or set the tagline in a different
  order.
* All the geometry comes from `Source/vamora_logo.py`. Regenerate files with
  `Source/export_artwork.py` rather than editing exports by hand, so the PCB, plate, case and artwork
  stay identical.
