# Vamora75

![Vamora75 assembled](Previews/assembled.png)

Vamora75 is an 82-key, 75 % mechanical keyboard with a Windows ANSI layout. It has hot-swap
sockets, a tab-gasket mount, a 6° typing angle, an on-board RP2040 and USB-C. It was designed by
a Vietnamese, American and Moroccan team. Their badge, a keycap carrying an interlaced star with
the tagline **VIỆT NAM · USA · المغرب**, is on the PCB, the plate and the case bottom.

**Revision 1.0: complete and checked in software, not built yet.** ERC, DRC, schematic parity,
plate DRC, CAD interference checks and firmware tests all pass. See
[validation/STATUS.md](validation/STATUS.md) and the open items in
[DESIGN_REVIEW.md](DESIGN_REVIEW.md). Build one prototype before a group order.

## Repository

| Folder | Contents |
|---|---|
| [PCB/](PCB) | KiCad 10 project: schematic, 2-layer board, project footprint library with 3D models, custom DRC rules |
| [Plate/](Plate) | KiCad boards for ordering the FR4 plate as a PCB (standard and flex-cut) |
| [Mechanical/](Mechanical) | Case (one-piece and 4-piece print split), plate DXF/STEP/STL, gasket and foam DXFs, full assembly STEP, PCBA STEP, key positions |
| [Manufacturing/](Manufacturing) | JLCPCB-ready Gerbers/drill, BOM + CPL, schematic PDF, assembly drawing, plate Gerbers, whole-kit BOM, [FABRICATION.md](Manufacturing/FABRICATION.md) |
| [Firmware/](Firmware) | QMK + VIA source, VIA definition, CircuitPython (no compiler needed), KLE layout |
| [Artwork/](Artwork) | Logo in SVG/PNG/DXF, brand sheet, [LOGO.md](Artwork/LOGO.md), the poem |
| [Previews/](Previews) | Renders |
| [Source/](Source) | Python generators for everything (`build_all.py`). See [Source/README.md](Source/README.md) |
| [validation/](validation) | ERC/DRC/mechanical/firmware reports |
| [Archive/rev0.1/](Archive/rev0.1) | The original rev 0.1 project, unchanged |
| [Reference/](Reference) | Input snapshots (Keyboard75, Aster75) |

## Specifications

| | |
|---|---|
| Layout | 82 keys: exploded 75 % Windows ANSI with an F-row in clusters, a Del/Home/PgUp/PgDn/End column, arrows, 1.75u RShift and 6.25u space ([layout](Previews/layout.png)) |
| Switches | Any MX-compatible switch, 3- or 5-pin, in Kailh CPG151101S11 hot-swap sockets |
| Stabilisers | PCB-mount screw-in: Backspace (2u), Enter and LShift (2.25u), Space (6.25u), all in standard orientation |
| Controller | RP2040, W25Q16JV 2 MB flash and 12 MHz crystal (the Raspberry Pi Pico core circuit), with BOOT and RESET buttons |
| USB | USB-C (HRO TYPE-C-31-M-12), USB 2.0 full speed, 5.1 kΩ CC resistors (works with C-C and A-C cables), USBLC6-2SC6 ESD protection, 0.5 A PTC fuse, XC6206 3.3 V LDO |
| Matrix | 6 x 16, COL2ROW, one 1N4148W per key |
| PCB | 334.61 x 129.83 mm, 2 layers, 1.6 mm, all parts on the bottom (one-sided SMT), GND pour on both layers |
| Plate | FR4, 1.5 mm (1.6 mm also fits), 8 gasket tabs, optional flex cuts, gold (ENIG) emblem and wordmark |
| Mount | Tab-gasket sandwich: 16 gaskets of 20 x 4.5 x 2 mm, 20 % compression. PCB and plate float as one unit. |
| Case | Two pieces, 6° typing angle, 21.0 mm high at the front and 37.1 mm at the rear, 358.6 x 156.7 mm. 8 M3 screws into heat-set inserts. Print it in one piece or as 4 pieces (fits 250 x 210 mm beds), or machine it. |
| Firmware | QMK + VIA, or CircuitPython |

![Exploded](Previews/exploded.png)

## Getting started

1. Read [DESIGN_REVIEW.md](DESIGN_REVIEW.md), which covers the gasket-mount question, what changed
   from rev 0.1 and what to check on the first prototype.
2. Order the PCBA, the plate, the case and the soft parts:
   [Manufacturing/FABRICATION.md](Manufacturing/FABRICATION.md).
3. Assemble it: [BUILD_GUIDE.md](BUILD_GUIDE.md).
4. Flash the firmware: [Firmware/README.md](Firmware/README.md).
5. To change the design, edit the parameter files and rebuild: [Source/README.md](Source/README.md).

| PCB bottom (all parts, logo, poem) | Case bottom (engraved badge) |
|---|---|
| ![PCB bottom](Previews/pcb_bottom.png) | ![Case bottom](Previews/bottom.png) |

![Brand sheet](Artwork/Vamora75_brand_sheet.png)

## Credits

Designed by the Vamora team (Việt Nam, USA, Morocco). For third-party data, fonts and licences
see [ATTRIBUTION.md](ATTRIBUTION.md) and [Licenses/](Licenses). The change history is in
[CHANGELOG.md](CHANGELOG.md).
