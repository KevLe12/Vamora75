# Fabrication notes

## Main PCB

Use `main_gerbers.zip` and both PTH and NPTH drills. 334.6125 × 129.825 mm, 2 layers, FR4 1.6 mm, 1 oz copper. Minimum design clearance 0.20 mm, nominal tracks 0.25 mm, vias 0.60 / 0.30 mm. Lead-free HASL or ENIG. No USB impedance-controlled traces are present on the carrier: USB is on the purchased RP2040-Zero module.

Silkscreen contains Vietnamese text and the Vamora logo on B.SilkS. **Do not mirror the Gerbers yourself.** Bottom silkscreen is already correctly oriented for underside viewing. Preserve Unicode-derived artwork as plotted; inspect the boardhouse's rendering. Silk must not print on exposed copper.

Placement CSV is a reference, not a turnkey PCBA order. The RP2040-Zero is a hand-installed module; hot-swap sockets and diodes are underneath. Confirm assembler bottom-side angle/coordinate conventions against the native KiCad board and preview before ordering assembly. Footprints are self-contained in the PCB folder.

## FR4 plate

Use `plate_gerbers.zip`, `Mechanical/plate_FR4_1p5mm.dxf`, or `Mechanical/plate_FR4_1p5mm.step`, together with these notes. The Gerber board has outline and routed internal openings, **no electrical circuit**. Material FR4, **finished thickness 1.50 mm**, target tolerance ±0.10 mm or better, no copper required. If ordering through a PCB service, explicitly confirm a mechanically routed non-electrical plate and all internal cutouts. There are no plated holes or component assembly.

Switch openings are 14 × 14 mm nominal. Ask for internal corner radius ≤0.5 mm; verify selected MX switch clips on a sample before ordering the full batch. Stabilizer openings are 8 × 18.4 mm. Supplier routing tolerance and switch/stabilizer variations need physical fit testing. Deburr edges; do not change the opening sizes automatically or rescale the DXF.

Plate tabs are part of the outline and must remain. This plate is incompatible with the original Aster75 83-key PCB.

## Case and gaskets

Print the two case STLs at 100% scale, in millimetres, or use STEP for editing. See the build guide for printer size, screws, pilots and controller spacing. Cut twelve gasket pieces from 2 mm soft foam using the included DXF. The floor logo is engraved into the solid model.
