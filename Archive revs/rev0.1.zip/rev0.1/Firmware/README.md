# Vamora75 firmware

## Included flashable option: CircuitPython

`CircuitPython/firmware.uf2` is the official **CircuitPython 10.3.1 build for Waveshare RP2040-Zero**, not a newly compiled custom QMK binary. The accompanying four Python files implement the Vamora75 keyboard. No extra Python libraries are required on the module.

1. Hold the module's BOOT button while connecting USB. The RP2040 ROM drive appears, normally `RPI-RP2`.
2. Copy `firmware.uf2` to that drive. Wait for the new `CIRCUITPY` drive.
3. Copy `code.py`, `boot.py`, `keymap.py`, and `report.py` into the root of `CIRCUITPY`. Safely eject and reconnect.
4. In normal operation the keyboard hides its storage/serial interfaces and supports USB boot-keyboard mode. To edit files later, **hold Esc while connecting USB**; this exposes `CIRCUITPY` and serial maintenance access. Physical BOOT remains available for recovery.

Windows should use a US keyboard layout to match the key legends. Left Win sends GUI; right Fn selects media/utility actions. Fn+F1 mute; F2 volume down; F3 volume up; F4 play/pause; F5 previous; F6 next; F12 Print Screen; Home Insert; Esc enters UF2 bootloader. Base layout has dedicated Del, Home, PgUp, PgDn, End and arrows.

CircuitPython sends six simultaneous ordinary keys plus modifiers, with a defined rollover error for larger chords. It scans COL2ROW with 5 ms debounce. Logic and all 82 key assignments have been tested on the host; hardware scan timing, USB enumeration and sleep/wake remain untested. There is no RGB implementation.

Official binary source: https://circuitpython.org/board/waveshare_rp2040_zero/
Runtime documentation: https://docs.circuitpython.org/en/latest/shared-bindings/usb_hid/index.html
Runtime licensing: `Licenses/CircuitPython-LICENSE.txt`; upstream source: https://github.com/adafruit/circuitpython/tree/10.3.1

## Alternative: QMK source

Copy `vamora75` into a QMK checkout as `keyboards/custom/vamora75`, then run:

```sh
qmk compile -kb custom/vamora75 -km default
```

Flash the resulting UF2 using the BOOT button. QMK source enables NKRO and shares the same layout and GPIO mapping. **The supplied QMK source has not been compiled here**, and there is no Vamora75 QMK UF2 in this package. Do not flash Aster75's ATmega HEX onto an RP2040.

## Pin mapping

Rows ROW0–ROW6: GP0–GP6. Columns COL0–COL11: GP7–GP15, GP26, GP27, GP28. GP29 is intentionally unused. Matrix positions are in `layout.json` and `Mechanical/key_positions.csv`. The custom schematic's module pin numbers refer to its pad numbering, not a bare RP2040 package.
