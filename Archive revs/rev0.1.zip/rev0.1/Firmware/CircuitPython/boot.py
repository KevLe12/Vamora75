"""Hold Esc while connecting USB for writable CIRCUITPY maintenance mode."""
import time, digitalio, microcontroller, usb_hid, usb_cdc, usb_midi, storage
c=digitalio.DigitalInOut(microcontroller.pin.GPIO7)
r=digitalio.DigitalInOut(microcontroller.pin.GPIO0)
r.switch_to_input(pull=digitalio.Pull.DOWN);c.switch_to_output(value=True)
time.sleep(.01);maintenance=r.value;c.deinit();r.deinit()
usb_midi.disable()
if not maintenance:
    storage.disable_usb_drive();usb_cdc.disable()
usb_hid.set_interface_name('Vamora75')
usb_hid.enable((usb_hid.Device.KEYBOARD,usb_hid.Device.CONSUMER_CONTROL),boot_device=0 if maintenance else 1)
