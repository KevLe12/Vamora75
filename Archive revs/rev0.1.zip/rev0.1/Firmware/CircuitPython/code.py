"""Vamora75: 7x12 COL2ROW matrix, RP2040-Zero, Windows ANSI."""
import time, digitalio, microcontroller, usb_hid
from report import reports

keyboard=next(d for d in usb_hid.devices if d.usage_page==1 and d.usage==6)
consumer=next((d for d in usb_hid.devices if d.usage_page==12 and d.usage==1),None)
rows=[];cols=[]
for gp in range(7):
    p=digitalio.DigitalInOut(getattr(microcontroller.pin,'GPIO'+str(gp)))
    p.switch_to_input(pull=digitalio.Pull.DOWN);rows.append(p)
for gp in list(range(7,16))+[26,27,28]:
    p=digitalio.DigitalInOut(getattr(microcontroller.pin,'GPIO'+str(gp)))
    p.switch_to_output(value=False);cols.append(p)
raw=[False]*84;stable=[False]*84;changed=[0.0]*84
last_k=None;last_c=None
while True:
    now=time.monotonic()
    for c,col in enumerate(cols):
        col.value=True
        time.sleep(.00002)
        for r,row in enumerate(rows):
            i=r*12+c;value=row.value
            if value!=raw[i]:raw[i]=value;changed[i]=now
            elif now-changed[i]>=.005:stable[i]=value
        col.value=False
    k,c,boot=reports({i for i,v in enumerate(stable) if v})
    if boot:
        keyboard.send_report(bytes(8))
        if consumer:consumer.send_report(bytes(2))
        microcontroller.on_next_reset(microcontroller.RunMode.UF2);microcontroller.reset()
    try:
        if k!=last_k:keyboard.send_report(k);last_k=k
        if consumer and c!=last_c:consumer.send_report(c);last_c=c
    except OSError:
        # Retry full current state after a temporary USB disconnect/suspend.
        last_k=None;last_c=None
    time.sleep(.001)
