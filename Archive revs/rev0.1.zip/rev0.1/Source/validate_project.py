"""Cross-check final files: schematic nets, PCB pads, keymap, plate and UF2."""
import json,struct,hashlib,xml.etree.ElementTree as ET
from pathlib import Path
from collections import defaultdict
import sexpdata as sx
from shapely.geometry import Polygon,Point
R=Path(__file__).resolve().parents[1]
def tag(o):return str(o[0]) if isinstance(o,list) and o else ''
def one(o,k):return next((z for z in o if tag(z)==k),None)
b=sx.loads((R/'PCB/Vamora75.kicad_pcb').read_text(encoding='utf-8'));d=json.loads((R/'layout.json').read_text())
fp={};pcb_nets=defaultdict(set)
for o in b:
    if tag(o)!='footprint':continue
    ref=next(z[2] for z in o if tag(z)=='property' and z[1]=='Reference');fp[ref]=o
    for p in o:
        if tag(p)=='pad' and one(p,'net'):pcb_nets[str(one(p,'net')[1])].add((ref,str(p[1])))
sch_nets={n.attrib['name']:{(p.attrib['ref'],p.attrib['pin']) for p in n.findall('node')} for n in ET.parse(R/'validation/schematic.net.xml').getroot().findall('./nets/net')}
assert dict(pcb_nets)==sch_nets,'PCB/schematic net membership differs'
def net(ref,pad):return str(one(next(z for z in fp[ref] if tag(z)=='pad' and str(z[1])==str(pad)),'net')[1])
polydata=json.loads((R/'validation/plate-polygon.json').read_text());poly=Polygon(polydata['outer'],polydata['holes']);H=d['board_mm'][1]+24
for k in d['keys']:
    assert all(abs(a-z)<0.00001 for a,z in zip(one(fp[k['ref']],'at')[1:3],[k['cx'],k['cy']]))
    assert net(k['ref'],1)==f'/COL{k["mc"]}'
    assert net(k['ref'],2)==f'/KEY_{k["n"]}' and net(k['diode'],2)==f'/KEY_{k["n"]}'
    assert net(k['diode'],1)==f'/ROW{k["mr"]}'
    x=k['cx']-8;y=H+8-k['cy']
    opening=next(Polygon(h) for h in polydata['holes'] if Polygon(h).contains(Point(x,y)))
    assert abs(opening.area-196)<1e-6
for pin,name in d['module_pins'].items():assert net('U1',pin)=='/'+name
assert len({(k['mr'],k['mc']) for k in d['keys']})==82
uf=(R/'Firmware/CircuitPython/firmware.uf2').read_bytes();assert len(uf)%512==0
nums=[];ranges=[]
for i in range(0,len(uf),512):
    block=uf[i:i+512];m0,m1,flags,address,size,num,count,family=struct.unpack('<8I',block[:32])
    assert m0==0x0A324655 and m1==0x9E5D5157 and struct.unpack('<I',block[508:])[0]==0x0AB16F30
    assert flags&0x2000 and family==0xE48BFF56 and size<=476
    assert count==len(uf)//512 and 0x10000000<=address<0x10200000 and address+size<=0x10200000
    nums.append(num);ranges.append((address,address+size))
assert sorted(nums)==list(range(len(nums)))
for (a,z),(n,e) in zip(sorted(ranges),sorted(ranges)[1:]):assert z<=n
drc=json.loads((R/'validation/drc.json').read_text());erc=json.loads((R/'validation/erc.json').read_text());plate=json.loads((R/'validation/plate-drc.json').read_text())
assert not drc['violations'] and not drc['unconnected_items'] and not drc['schematic_parity']
assert all(not s['violations'] for s in erc['sheets']) and not plate['violations']
checks={'matrix_keys':82,'matching_net_groups':len(pcb_nets),'plate_switch_openings_14mm':82,'plate_stabilizer_openings':8,'module_pins_match':True,'native_drc':'pass','native_erc':'pass','native_schematic_parity':'pass','uf2_family':'RP2040','uf2_blocks':len(nums),'uf2_sha256':hashlib.sha256(uf).hexdigest(),'physical_prototype_tested':False}
(R/'validation/project-checks.json').write_text(json.dumps(checks,indent=2));print(checks)

