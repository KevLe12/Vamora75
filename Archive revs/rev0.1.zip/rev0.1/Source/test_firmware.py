import sys,json
from pathlib import Path
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'Firmware/CircuitPython'))
from report import reports
from keymap import KEYMAP,FN_INDEX,FN_ACTIONS
d=json.loads((R/'layout.json').read_text());count=0
for key in d['keys']:
    i=key['mr']*12+key['mc'];k,c,b=reports({i});v=KEYMAP[i]
    assert len(k)==8 and len(c)==2 and not b
    if v>=224:assert k[0]==1<<(v-224)
    elif v:assert k[2]==v
    else:assert k==bytes(8)
    count+=1
for i,(kind,value) in FN_ACTIONS.items():
    k,c,b=reports({FN_INDEX,i})
    if kind=='consumer':assert int.from_bytes(c,'little')==value and k==bytes(8)
    if kind=='boot':assert b
    if kind=='key':assert k[2]==value
assert reports(set())==(bytes(8),bytes(2),False)
seven=[i for i,v in enumerate(KEYMAP) if 4<=v<224][:7]
assert reports(set(seven))[0][2:]==bytes([1]*6)
assert reports(set(seven[:6]))[0][2:]!=bytes([1]*6)
for f in (R/'Firmware/CircuitPython').glob('*.py'):compile(f.read_text(),str(f),'exec')
result={'individual_keys':count,'fn_actions':len(FN_ACTIONS),'release_and_rollover_tests':'pass','syntax':'pass','hardware_tested':False,'qmk_compiled':False}
(R/'validation/firmware.json').write_text(json.dumps(result,indent=2));print(result)
