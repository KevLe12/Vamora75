import json,uuid
from pathlib import Path
import sexpdata as sx
R=Path(__file__).resolve().parents[1]
P=json.loads((R/'validation/plate-polygon.json').read_text());H=json.loads((R/'layout.json').read_text())['board_mm'][1]+24
main=sx.loads((R/'PCB/Vamora75.kicad_pcb').read_text(encoding='utf-8'))
keep={'version','generator','generator_version','general','paper','layers','setup','embedded_fonts'}
b=[main[0]]+[x for x in main[1:] if isinstance(x,list) and str(x[0]) in keep]
for x in b:
    if isinstance(x,list) and x and str(x[0])=='general':x[:]=sx.loads('(general (thickness 1.5))')
for ring in [P['outer']]+P['holes']:
    for a,z in zip(ring,ring[1:]):
        b.append(sx.loads(f'(gr_line (start {a[0]} {H-a[1]}) (end {z[0]} {H-z[1]}) (stroke (width .05) (type solid)) (layer "Edge.Cuts") (uuid "{uuid.uuid4()}"))'))
(R/'Mechanical/Vamora75_FR4_plate.kicad_pcb').write_text(sx.dumps(b),encoding='utf-8')
print('Created FR4 plate fabrication board',len(P['holes']),'internal openings')
