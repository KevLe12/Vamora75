import json
from pathlib import Path
R=Path(__file__).resolve().parents[1];d=json.loads((R/'layout.json').read_text())
codes={'KC_'+chr(65+i):4+i for i in range(26)}
codes.update({'KC_'+str(i):29+i for i in range(1,10)});codes['KC_0']=39
codes.update({'KC_'+k:v for k,v in {'ENT':40,'ESC':41,'BSPC':42,'TAB':43,'SPC':44,'MINS':45,'EQL':46,'LBRC':47,'RBRC':48,'BSLS':49,'SCLN':51,'QUOT':52,'GRV':53,'COMM':54,'DOT':55,'SLSH':56,'CAPS':57,'DEL':76,'HOME':74,'PGUP':75,'END':77,'PGDN':78,'RIGHT':79,'LEFT':80,'DOWN':81,'UP':82,'LCTL':224,'LSFT':225,'LALT':226,'LGUI':227,'RCTL':228,'RSFT':229,'RALT':230}.items()})
codes.update({'KC_F'+str(i):57+i for i in range(1,13)});codes['MO(1)']=0
km=[0]*84;actions={};fn=None
media={'KC_F1':0xE2,'KC_F2':0xEA,'KC_F3':0xE9,'KC_F4':0xCD,'KC_F5':0xB6,'KC_F6':0xB5}
for k in d['keys']:
    i=k['mr']*12+k['mc'];km[i]=codes[k['kc']]
    if k['kc']=='MO(1)':fn=i
    if k['kc'] in media:actions[i]=('consumer',media[k['kc']])
    if k['kc']=='KC_ESC':actions[i]=('boot',0)
    if k['kc']=='KC_F12':actions[i]=('key',70)
    if k['kc']=='KC_HOME':actions[i]=('key',73)
(R/'Firmware/CircuitPython/keymap.py').write_text('# Generated from layout.json. Index = matrix row * 12 + column.\nKEYMAP = '+repr(km)+'\nFN_INDEX = '+str(fn)+'\nFN_ACTIONS = '+repr(actions)+'\n')
print('Generated 82-key map, Fn position',fn)
