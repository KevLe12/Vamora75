import json
from pathlib import Path
import sexpdata as sx
R=Path(__file__).resolve().parents[1]
def tag(o):return str(o[0]) if isinstance(o,list) and o else ''
def one(o,k):return next((v for v in o if tag(v)==k),None)
# COL9 shortcuts crossed other newly straightened routes. Restore this net's
# original verified geometry; all remaining shortcuts checked against it.
g=json.loads((R/'validation/routing-geometry.json').read_text())
t=json.loads((R/'validation/optimized-tracks.json').read_text())
t=[z for z in t if z['net']!='/COL9']+[z for z in g['tracks'] if z['net']=='/COL9']
(R/'validation/optimized-tracks.json').write_text(json.dumps(t))
stats=json.loads((R/'validation/routing-cleanup.json').read_text());stats['after_segments']=len(t);stats['restored_net']='/COL9'
(R/'validation/routing-cleanup.json').write_text(json.dumps(stats,indent=2))
exec((R/'Source/apply_optimized.py').read_text())
f=R/'PCB/Vamora75.kicad_pcb';b=sx.loads(f.read_text(encoding='utf-8'))
for o in b:
    if tag(o)!='footprint':continue
    ref=next(z[2] for z in o if tag(z)=='property' and z[1]=='Reference')
    if ref=='U1':
        for z in o:
            if tag(z)=='pad' and z[1]=='20':
                n=one(z,'net')
                if n:n[:]=[sx.Symbol('net'),'unconnected-(U1-GP29-Pad20)']
                else:z.append([sx.Symbol('net'),'unconnected-(U1-GP29-Pad20)'])
f.write_text(sx.dumps(b),encoding='utf-8')
f=R/'PCB/Vamora75.kicad_sch';b=sx.loads(f.read_text(encoding='utf-8-sig'))
def snap(at):
    at[1]=round(round(at[1]/1.27)*1.27,4);at[2]=round(round(at[2]/1.27)*1.27,4)
for o in b:
    if tag(o) in ['symbol','label','global_label','junction','no_connect']:
        a=one(o,'at')
        if a:snap(a)
        if tag(o)=='symbol':
            ref=next((z[2] for z in o if tag(z)=='property' and z[1]=='Reference'),'')
            if ref.startswith('TP'):one(o,'in_bom')[1]=sx.Symbol('no')
    if tag(o)=='wire':
        for point in one(o,'pts')[1:]:snap(point)
f.write_text(sx.dumps(b),encoding='utf-8')
print('Restored COL9, aligned schematic grid, corrected parity metadata')
