import json,uuid
from pathlib import Path
import sexpdata as sx
R=Path(__file__).resolve().parents[1];f=R/'PCB/Vamora75.kicad_pcb';b=sx.loads(f.read_text(encoding='utf-8'))
b[:]=[o for o in b if not (isinstance(o,list) and o and str(o[0])=='segment')]
for t in json.loads((R/'validation/optimized-tracks.json').read_text()):
    a,z=t['a'],t['b'];b.append(sx.loads(f'(segment (start {a[0]} {a[1]}) (end {z[0]} {z[1]}) (width {t["w"]}) (layer "{t["layer"]}") (net {json.dumps(t["net"])}) (uuid "{uuid.uuid4()}"))'))
f.write_text(sx.dumps(b),encoding='utf-8');print('Applied optimized routes')

