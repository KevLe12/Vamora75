"""Render exported STL geometry; keycaps are illustrative rectangular envelopes."""
import json,math
from pathlib import Path
import vtk
from PIL import Image,ImageDraw,ImageFont
R=Path(__file__).resolve().parents[1];D=json.loads((R/'layout.json').read_text());BW,BH=D['board_mm'];W,H=BW+24,BH+24
P=R/'Previews';P.mkdir(exist_ok=True)
def mesh(name,color,shift=0):
    rd=vtk.vtkSTLReader();rd.SetFileName(str(R/'Mechanical'/name));rd.Update()
    mp=vtk.vtkPolyDataMapper();mp.SetInputConnection(rd.GetOutputPort());a=vtk.vtkActor();a.SetMapper(mp);a.GetProperty().SetColor(*color);a.GetProperty().SetSpecular(.3);a.GetProperty().SetSpecularPower(30);a.SetPosition(0,0,shift);return a
def cap(k,shift=0):
    x=k['cx']-8;y=H+8-k['cy'];s=vtk.vtkCubeSource();s.SetCenter(x,y,31+shift);s.SetXLength(k['w']*19.05-1.3);s.SetYLength(17.7);s.SetZLength(7)
    mp=vtk.vtkPolyDataMapper();mp.SetInputConnection(s.GetOutputPort());a=vtk.vtkActor();a.SetMapper(mp)
    a.GetProperty().SetColor(*((.78,.49,.21) if k['label'] in ['Esc','Enter'] else (.77,.80,.76) if k['w']==1 else (.30,.40,.41)));return a
for mode in ['assembled','exploded','case_bottom']:
    ren=vtk.vtkRenderer();ren.SetBackground(.045,.065,.085)
    ren.AddActor(mesh('case_bottom.stl',(.16,.25,.27)))
    if mode!='case_bottom':
        ren.AddActor(mesh('case_top.stl',(.16,.25,.27),60 if mode=='exploded' else 0))
        ren.AddActor(mesh('plate_FR4_1p5mm.stl',(.13,.42,.33),38 if mode=='exploded' else 0))
        ren.AddActor(mesh('pcb_envelope.stl',(.08,.28,.21),18 if mode=='exploded' else 0))
        ren.AddActor(mesh('controller_envelope.stl',(.14,.2,.55),18 if mode=='exploded' else 0))
        for k in D['keys']:ren.AddActor(cap(k,80 if mode=='exploded' else 0))
    cam=ren.GetActiveCamera();cam.SetFocalPoint(W/2,H/2,40 if mode=='exploded' else 10)
    if mode=='case_bottom':cam.SetPosition(W/2,-H*.8,-420);cam.SetViewUp(0,1,0)
    else:cam.SetPosition(W*.9,-H*1.6,360 if mode=='assembled' else 410);cam.SetViewUp(0,0,1)
    cam.ParallelProjectionOn();cam.SetParallelScale(145 if mode=='exploded' else 124)
    win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(1500,950);win.AddRenderer(ren);win.SetMultiSamples(8);win.Render()
    shot=vtk.vtkWindowToImageFilter();shot.SetInput(win);shot.Update();wr=vtk.vtkPNGWriter();wr.SetFileName(str(P/(mode+'.png')));wr.SetInputConnection(shot.GetOutputPort());wr.Write();win.Finalize()
    im=Image.open(P/(mode+'.png'));dr=ImageDraw.Draw(im);font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',30)
    dr.text((45,35),'VAMORA75  /  '+mode.replace('_',' ').upper(),font=font,fill='#edf4ef')
    small=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',19)
    dr.text((45,890),'Actual case and plate geometry · keycaps shown as fit envelopes · prototype revision 0.1',font=small,fill='#a6bfbc');im.save(P/(mode+'.png'))
    print(mode,flush=True)
# Labelled layout from the shared coordinates.
im=Image.new('RGB',(1500,730),'#101923');dr=ImageDraw.Draw(im);font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',15)
dr.text((35,20),'VAMORA75 | 82-key Windows ANSI | RP2040-Zero | MX hot-swap',font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',28),fill='white')
scale=4.15
for k in D['keys']:
    x=(k['cx']-20)*scale+40;y=(k['cy']-20)*scale+80;w=(k['w']*19.05-1.1)*scale;h=18*scale
    dr.rounded_rectangle((x-w/2,y-h/2,x+w/2,y+h/2),radius=5,fill='#b98542' if k['label'] in ['Esc','Enter'] else '#344c54',outline='#789395',width=1)
    dr.text((x,y),k['label'],font=font,anchor='mm',fill='white')
im.save(P/'layout.png')
