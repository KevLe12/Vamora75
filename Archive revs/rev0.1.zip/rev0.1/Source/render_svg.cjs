const fs=require('fs');
const sharp=require(process.env.VAMORA_SHARP || 'sharp');
(async()=>{
  for(const n of ['Previews/pcb_bottom','Previews/pcb_top','Artwork/pcb_silkscreen_bottom']) {
    let s=fs.readFileSync(n+'.svg','utf8');
    s=s.replace(/width="[^"]+"/, 'width="2600"').replace(/height="[^"]+"/, 'height="1100"');
    await sharp(Buffer.from(s)).flatten({background:'#eef0e9'}).png().toFile(n+'.png');
  }
})();
