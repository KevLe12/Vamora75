"""Portable s-expression board editing; KiCad CLI performs native validation."""
import json, math, uuid, shutil
from pathlib import Path
import sexpdata as sx
R=Path(__file__).resolve().parents[1]
def tag(o):return str(o[0]) if isinstance(o,list) and o else ''
def one(o,k):return next((x for x in o if tag(x)==k),None)
def allof(o,k):return [x for x in o if tag(x)==k]
def uid():return str(uuid.uuid4())
f=R/'PCB/Vamora75.kicad_pcb';src=f.read_text(encoding='utf-8')
b=sx.loads(src)
b[:]=[o for o in b if not (tag(o)=='gr_text' and any(w in str(o[1]) for w in ['KEYBOARD75','VAMORA75','Nam quốc','Tiệt nhiên','Như hà','Nhữ đẳng','NAM QUỐC']))]
# Board text uses native KiCad stroke font with Vietnamese characters.
def text(s,x,y,size,layer='B.SilkS'):
    mir='(justify mirror)' if layer=='B.SilkS' else ''
    b.append(sx.loads(f'(gr_text {json.dumps(s,ensure_ascii=False)} (at {x} {y}) (layer "{layer}") (uuid "{uid()}") (effects (font (size {size} {size}) (thickness 0.15)) {mir}))'))
text('VAMORA75 / RP2040 / REV 0.1',244,46,1.1,'F.SilkS')
poem=['Nam quốc sơn hà Nam đế cư,','Tiệt nhiên định phận tại thiên thư.','Như hà nghịch lỗ lai xâm phạm,','Nhữ đẳng hành khan thủ bại hư.']
for i,line in enumerate(poem):text(line,208,43.5+i*1.65,.95)
text('NAM QUỐC SƠN HÀ',255,46,1);text('VAMORA75',145,46,1.2)
# One filled polygon shared in shape with the underside case engraving.
logo=[(-3,1.7),(-1.67,1.7),(0,-1.17),(1.67,1.7),(3,1.7),(0,-3.17)]
b.append(sx.loads('(gr_poly (pts '+''.join(f'(xy {124-x} {46-y})' for x,y in logo)+f') (stroke (width 0) (type solid)) (fill solid) (layer "B.SilkS") (uuid "{uid()}"))'))
for yy in [50,50.7]:b.append(sx.loads(f'(gr_line (start 121 {yy}) (end 127 {yy}) (stroke (width .25) (type solid)) (layer "B.SilkS") (uuid "{uid()}"))'))
# Do not retain previous attempt's logo primitives.
seen=set();clean=[]
for o in b:
    if tag(o) in ['gr_line','gr_poly'] and one(o,'layer') and one(o,'layer')[1]=='B.SilkS':
        # Delete only the outline variant from early generation.
        if tag(o)=='gr_line':
            a=one(o,'start')[1:];z=one(o,'end')[1:]
            if 120<=a[0]<=128 and 120<=z[0]<=128 and 41<a[1]<50:continue
            key=(tuple(a),tuple(z))
            if key in seen:continue
            seen.add(key)
    clean.append(o)
b=clean
f.write_text(sx.dumps(b),encoding='utf-8')
G={'tracks':[],'vias':[],'pads':[]}
for o in b:
    if tag(o)=='segment':G['tracks'].append({'a':one(o,'start')[1:],'b':one(o,'end')[1:],'w':one(o,'width')[1],'net':one(o,'net')[1],'layer':one(o,'layer')[1]})
    if tag(o)=='via':G['vias'].append({'xy':one(o,'at')[1:3],'r':one(o,'size')[1]/2,'net':one(o,'net')[1]})
    if tag(o)!='footprint':continue
    at=one(o,'at');x,y=at[1:3];a=math.radians(at[3] if len(at)>3 else 0)
    ref=next(z[2] for z in allof(o,'property') if z[1]=='Reference')
    for z in allof(o,'pad'):
        za=one(z,'at');px,py=za[1:3];xx=x+px*math.cos(a)+py*math.sin(a);yy=y-px*math.sin(a)+py*math.cos(a)
        size=one(z,'size')[1:];pa=math.radians(za[3] if len(za)>3 else 0)
        ww=abs(size[0]*math.cos(pa))+abs(size[1]*math.sin(pa));hh=abs(size[0]*math.sin(pa))+abs(size[1]*math.cos(pa))
        dr=one(z,'drill');drill=[dr[1],dr[1]] if dr and isinstance(dr[1],(float,int)) else [0,0]
        layers=one(z,'layers')[1:];layers=['F.Cu','B.Cu'] if '*.Cu' in layers else [l for l in layers if l in ['F.Cu','B.Cu']]
        net=one(z,'net')
        G['pads'].append({'ref':ref,'num':z[1],'net':net[1] if net else 0,'xy':[xx,yy],'size':size,'drill':drill,'bbox':[[xx-ww/2,yy-hh/2],[xx+ww/2,yy+hh/2]],'layers':layers,'circle':str(z[3])=='circle'})
(R/'validation/routing-geometry.json').write_text(json.dumps(G))
print('Prepared board:',len(G['tracks']),'segments',len(G['vias']),'vias')
