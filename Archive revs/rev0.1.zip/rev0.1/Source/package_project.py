"""Create BOM, manufacturing ZIPs, checked project manifest and full project ZIP."""
import csv,json,hashlib,zipfile,math
from pathlib import Path
R=Path(__file__).resolve().parents[1]
rows=[
('SW1-SW82',82,'Kailh CPG151101S11','MX hot-swap socket; bottom soldered'),
('D1-D82',82,'1N4148W','SOD-123; cathode pad 1 = ROW'),
('U1',1,'Original Waveshare RP2040-Zero','USB-C; bottom mounted; components face floor'),
('U1 pins',23,'2.54 mm pitch straight pins','Two side rows of 9 + one row of 5; 3.5 mm board gap jig'),
('Switches',82,'Full-height MX-compatible switches','3-pin or 5-pin; select force and sound preference'),
('Stabilizers',3,'2u Cherry-compatible PCB stabilizers','Backspace, Enter, left Shift; screw-in clearance to verify'),
('Space stabilizer',1,'6.25u Cherry-compatible PCB stabilizer','100 mm housing spacing; reversed drilling'),
('Keycaps',1,'US ANSI / Windows compatible set','6.25u Space; 1.75u RShift; 1u right Alt/Fn/Ctrl'),
('Main PCB',1,'Vamora75 carrier PCB','334.6125 x 129.825 x 1.6 mm FR4; two copper layers'),
('Plate',1,'Vamora75 FR4 plate','1.50 mm finished thickness; gasket tabs; no circuitry'),
('Case bottom',1,'Printed PETG/ABS/ASA','case_bottom.step / .stl; engraved underside'),
('Case top',1,'Printed PETG/ABS/ASA','case_top.step / .stl'),
('Gaskets',12,'Soft foam 24 x 5.5 x 2 mm','Nominal compression to 1.6 mm'),
('Case screws',8,'M3 button-head; 24 mm under-head length','Head diameter <=6 mm; shorten M3x25 by 1 mm; tap top pilots M3'),
('Feet',4,'Self-adhesive rubber feet, 2 mm thick','Keep service opening free'),
('USB cable',1,'USB-C data cable','Slim plug that seats through 20 x 8.5 mm recessed tunnel'),
('Assembly supplies',1,'Solder, flux, temporary 3.5 mm jig','Insulating stabilizer washers as required')]
with (R/'Manufacturing/BOM.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f);w.writerow(['Reference','Quantity','Part','Notes']);w.writerows(rows)
T=json.loads((R/'validation/optimized-tracks.json').read_text());s=json.loads((R/'validation/routing-cleanup.json').read_text())
s['after_length_mm']=sum(math.dist(t['a'],t['b']) for t in T);s['segment_reduction_percent']=round(100*(1-len(T)/s['before_segments']),1)
(R/'validation/routing-cleanup.json').write_text(json.dumps(s,indent=2))
for name in ['main_gerbers','plate_gerbers']:
    with zipfile.ZipFile(R/'Manufacturing'/(name+'.zip'),'w',zipfile.ZIP_DEFLATED) as z:
        for f in (R/'Manufacturing'/name).iterdir():z.write(f,f.name)
included=['PCB','Mechanical','Firmware','Artwork','Source','Manufacturing','Previews','validation','Licenses','Reference']
files=[p for folder in included for p in (R/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.kicad_prl')]
files += [R/n for n in ['README.md','BUILD_GUIDE.md','ATTRIBUTION.md','layout.json']]
manifest={'project':'Vamora75','revision':'0.1','files':{str(p.relative_to(R)).replace('\\','/'):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)}}
(R/'MANIFEST.json').write_text(json.dumps(manifest,indent=2));files.append(R/'MANIFEST.json')
with zipfile.ZipFile(R/'Vamora75_complete_project.zip','w',zipfile.ZIP_DEFLATED) as z:
    for f in files:z.write(f,'Vamora75/'+str(f.relative_to(R)).replace('\\','/'))
print('Packaged',len(files),'files; ZIP bytes',(R/'Vamora75_complete_project.zip').stat().st_size)
