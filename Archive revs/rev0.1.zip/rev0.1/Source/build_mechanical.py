"""Vamora75 parametric gasket case and FR4 plate. Millimetres, Z up.
Derived construction approach: supplied Aster75 generator; geometry rebuilt
for Keyboard75's 82-key RP2040-Zero board. Run with CadQuery, Shapely, ezdxf.
"""
import json
from pathlib import Path
import cadquery as cq
import ezdxf
from shapely.geometry import box
from shapely.ops import unary_union

R=Path(__file__).resolve().parents[1]; OUT=R/'Mechanical'
D=json.loads((R/'layout.json').read_text()); BW,BH=D['board_mm']
W,H=BW+24,BH+24
def rect(x0,y0,x1,y1,z0,z1):
    return cq.Workplane('XY').box(x1-x0,y1-y0,z1-z0,centered=(False,False,False)).translate((x0,y0,z0))
def cyl(x,y,r,z0,z1):return cq.Workplane('XY').center(x,y).circle(r).extrude(z1-z0).translate((0,0,z0))
def pocket(x0,y0,x1,y1,z0,z1,r=1):return rect(x0,y0,x1,y1,z0,z1).edges('|Z').fillet(r)
def blank(z0,z1):return pocket(0,0,W,H,z0,z1,5)
def xy(k):return k['cx']-20+12,H-12-(k['cy']-20)
tabs=[(x,y) for x in [85,W/2,W-65] for y in [8,H-8]]
screws=[(x,y) for x in [5,W/2+30,W-5] for y in [4,H-4]]+[(5,H/2),(W-5,H/2)]
platepoly=unary_union([box(11,11,W-11,H-11)]+[box(x-12,y-3,x+12,y+3) for x,y in tabs])
cuts=[]
for k in D['keys']:
    x,y=xy(k); cuts.append(box(x-7,y-7,x+7,y+7))
    if k['w']>=2:
        a=50 if k['w']==6.25 else 11.9
        for sx in [x-a,x+a]: cuts.append(box(sx-4,y-9.2,sx+4,y+9.2))
platepoly=platepoly.difference(unary_union(cuts))
assert platepoly.is_valid and platepoly.geom_type=='Polygon'
def solid(poly,z,h):
    wp=cq.Workplane('XY').polyline(list(poly.exterior.coords)[:-1]).close()
    for ring in poly.interiors:wp=wp.polyline(list(ring.coords)[:-1]).close()
    return wp.extrude(h).translate((0,0,z))
plate=solid(platepoly,20.1,1.5)
base=blank(0,20).cut(pocket(10,10,W-10,H-10,3,21))
top=blank(20,28).cut(pocket(10,10,W-10,H-10,19.9,23.2)).cut(pocket(11,11,W-11,H-11,23.2,29))
for x,y in tabs:
    base=base.cut(pocket(x-12.5,y-3.5,x+12.5,y+3.5,18.5,21,.4))
    top=top.cut(pocket(x-12.5,y-3.5,x+12.5,y+3.5,19.9,23.2,.4))
# USB tunnel admits overmoulded plugs to the recessed controller connector.
# Module PCB lower face z=9.9, upper face z=11.5, main PCB lower face z=15.
ux=12+31.575; uy=H-12-11.75
base=base.cut(rect(ux-10,H-14,ux+10,H+1,5.5,14))
# Service opening spans module buttons; inspect actual button positions on prototype.
base=base.cut(pocket(ux-8,uy-9,ux+8,uy+5,-1,3.1,1))
for x,y in screws:
    base=base.cut(cyl(x,y,1.7,-1,21)).cut(cyl(x,y,3,-1,2))
    top=top.cut(cyl(x,y,1.25,19.9,27))
# Original V/mountain and river mark; engraved 0.6 mm into the underside.
logo=[(-18,10),(-10,10),(0,-7),(10,10),(18,10),(0,-19)]
engr=cq.Workplane('XY').polyline([(W/2+x,H/2+y) for x,y in logo]).close().extrude(.6)
for yy in [-24,-28]:engr=engr.union(rect(W/2-18,H/2+yy,W/2+18,H/2+yy+1.5,0,.6))
base=base.cut(engr)
pcb=rect(12,12,W-12,H-12,15,16.6)
module=rect(ux-9,uy-11.75,ux+9,uy+11.75,6,11.5)
sockets=[]
for k in D['keys']:
    x,y=xy(k);sockets.append(rect(x-8.7,y-1.6,x+8.7,y+7.3,11.9,15))
gaskets=[rect(x-12,y-2.75,x+12,y+2.75,z,z+1.6) for x,y in tabs for z in [18.5,21.6]]
def overlap(a,b):
    q=a.intersect(b);return sum(s.Volume() for s in q.solids().vals())
checks={'case_size_mm':[W,H,28],'pcb_z_mm':[15,16.6],'plate_z_mm':[20.1,21.6],
        'plate_top_to_pcb_top_mm':5,'gasket_free_mm':[24,5.5,2],
        'gasket_installed_thickness_mm':1.6,'gasket_count':12,
        'module_main_board_gap_mm':3.5,'module_floor_clearance_mm':3,
        'socket_floor_clearance_mm':8.9,'pcb_case_overlap_mm3':overlap(pcb,base)+overlap(pcb,top),
        'plate_case_overlap_mm3':overlap(plate,base)+overlap(plate,top),
        'halves_overlap_mm3':overlap(base,top),'module_case_overlap_mm3':overlap(module,base)+overlap(module,top),
        'switch_count':len(D['keys']),'physical_fit_tested':False}
for key in ['pcb_case_overlap_mm3','plate_case_overlap_mm3','halves_overlap_mm3','module_case_overlap_mm3']:assert checks[key]<.001,(key,checks[key])
assy=cq.Assembly(name='Vamora75')
for name,shape,color in [('case_bottom',base,(.10,.14,.16)),('case_top',top,(.10,.14,.16)),('plate_FR4_1p5mm',plate,(.08,.30,.24)),('pcb_envelope',pcb,(.12,.37,.26)),('controller_envelope',module,(.2,.25,.4))]:
    assert shape.val().isValid(),name
    checks[name]={'valid':True,'solids':len(shape.solids().vals()),'volume_mm3':shape.val().Volume()}
    cq.exporters.export(shape,str(OUT/(name+'.step')))
    cq.exporters.export(shape,str(OUT/(name+'.stl')),tolerance=.08,angularTolerance=.15)
    assy.add(shape,name=name,color=cq.Color(*color))
for i,g in enumerate(gaskets):assy.add(g,name=f'gasket_{i+1}',color=cq.Color(.4,.4,.4))
assy.export(str(OUT/'Vamora75_assembly.step'))
for name,polys in [('plate_FR4_1p5mm',[platepoly]),('gaskets_2mm_12pieces',[box((i%3)*30,(i//3)*10,(i%3)*30+24,(i//3)*10+5.5) for i in range(12)])]:
    doc=ezdxf.new('R2010');doc.units=4;m=doc.modelspace()
    for poly in polys:
        m.add_lwpolyline(list(poly.exterior.coords)[:-1],close=True)
        for ring in poly.interiors:m.add_lwpolyline(list(ring.coords)[:-1],close=True)
    assert not doc.audit().has_errors;doc.saveas(OUT/(name+'.dxf'))
(R/'validation/mechanical.json').write_text(json.dumps(checks,indent=2))
(R/'validation/plate-polygon.json').write_text(json.dumps({'outer':list(platepoly.exterior.coords),'holes':[list(h.coords) for h in platepoly.interiors]}))
print(json.dumps(checks,indent=2))

