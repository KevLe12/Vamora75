# Project sources

The native editable master files are `PCB/Vamora75.kicad_pcb`, its matching schematic/project, and `layout.json`. KiCad 10.0.6 was used for the final checks and manufacturing plots.

Mechanical regeneration: install the packages in `requirements.txt`, then run `python Source/build_mechanical.py` from the project root. It generates STEP/STL, DXF, a shared assembly and intersection reports. `render_previews.py` renders those exported STLs with illustrative keycap envelopes. `plate_pcb.py` converts the exact plate contours into the non-electrical KiCad plate board.

`build_firmware_map.py` derives the CircuitPython keymap from the shared matrix/layout; `test_firmware.py` checks all individual keys, Fn actions, release and rollover logic. QMK source remains separately editable.

Electrical trace cleanup was performed with `prepare_pcb.py`, `optimize_routes.py`, `apply_optimized.py`, and `finalize_electrical.py`. The latter restores COL9 after native DRC detected crossing shortcuts, then snaps the schematic to its connection grid and fixes parity metadata. `validation/routing-geometry.json` is the pre-cleanup geometry; `optimized-tracks.json` is the final delivered trace set. Do not reuse these cached traces after moving components or changing the matrix. Always rerun native DRC/ERC and schematic parity after edits.

`Reference` contains input snapshots and the original Aster75 generator for provenance. They are not build outputs to send to a manufacturer. Only `Manufacturing` and the specifically named final `Mechanical` files belong in fabrication orders.

The `.tools` directory is an ignored local tool cache and is intentionally omitted from the project ZIP. Portable KiCad, CAD libraries and archive extractors were used there; they are not project dependencies to redistribute.
