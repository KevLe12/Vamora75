"""Straighten degree-two routing chains, preserving all electrical junctions.
Each candidate is collision checked against other-net copper and all drills.
KiCad DRC after application is the release gate.
"""
import json, math
from pathlib import Path
from collections import defaultdict
from shapely.geometry import LineString,Point,box
from shapely.ops import unary_union
from shapely.prepared import prep
R=Path(__file__).resolve().parents[1];G=json.loads((R/'validation/routing-geometry.json').read_text())
T=G['tracks'];groups=defaultdict(list)
for t in T:groups[t['net'],t['layer'],t['w']].append(t)
def pt(p):return tuple(round(x,6) for x in p)
def length(ps):return sum(math.dist(a,b) for a,b in zip(ps,ps[1:]))
result=[];stats={'before_segments':len(T),'before_length_mm':sum(math.dist(t['a'],t['b']) for t in T),'shortcuts':0}
for (net,layer,width),ts in groups.items():
    shapes=[]
    for t in T:
        if t['net']!=net and t['layer']==layer:shapes.append(LineString([t['a'],t['b']]).buffer(t['w']/2+.205+width/2))
    for z in G['vias']:
        if z['net']!=net:shapes.append(Point(z['xy']).buffer(z['r']+.205+width/2))
    for z in G['pads']:
        if z['net']!=net and layer in z['layers']:
            if z['circle']:s=Point(z['xy']).buffer(max(z['size'])/2+.205+width/2)
            else:s=box(*z['bbox'][0],*z['bbox'][1]).buffer(.205+width/2)
            shapes.append(s)
        if max(z['drill']) and z['net']!=net:shapes.append(Point(z['xy']).buffer(max(z['drill'])/2+.26+width/2))
    obstacle=prep(unary_union(shapes))
    adj=defaultdict(list)
    for i,t in enumerate(ts):
        adj[pt(t['a'])].append(i);adj[pt(t['b'])].append(i)
    anchors=set(pt(z['xy']) for z in G['vias'] if z['net']==net)|set(pt(z['xy']) for z in G['pads'] if z['net']==net)
    ends={p for p,ee in adj.items() if len(ee)!=2}|anchors
    used=set()
    for start in list(ends)+list(adj):
        for eid in adj[start]:
            if eid in used:continue
            chain=[start];cur=start;i=eid
            while True:
                used.add(i);t=ts[i];n=pt(t['b']) if pt(t['a'])==cur else pt(t['a']);chain.append(n)
                if n in ends or all(j in used for j in adj[n]):break
                cur=n;i=next(j for j in adj[n] if j not in used)
            out=[chain[0]];i=0
            while i<len(chain)-1:
                chosen=None
                for j in range(len(chain)-1,i+1,-1):
                    a,z=chain[i],chain[j];dx=z[0]-a[0];dy=z[1]-a[1];m=min(abs(dx),abs(dy));sx=1 if dx>=0 else -1;sy=1 if dy>=0 else -1
                    candidates=[[a,(a[0]+sx*m,a[1]+sy*m),z],[a,(z[0]-sx*m,z[1]-sy*m),z]]
                    if abs(dx)<1e-6 or abs(dy)<1e-6 or abs(abs(dx)-abs(dy))<1e-6:candidates.insert(0,[a,z])
                    for ps in candidates:
                        ps=[p for ii,p in enumerate(ps) if not ii or math.dist(p,ps[ii-1])>1e-6]
                        if len(ps)<2 or length(ps)>length(chain[i:j+1])+.00001:continue
                        if not obstacle.intersects(LineString(ps)):
                            chosen=(j,ps);break
                    if chosen:break
                if chosen:
                    j,ps=chosen;out.extend(ps[1:]);stats['shortcuts']+=1;i=j
                else:i+=1;out.append(chain[i])
            for a,z in zip(out,out[1:]):result.append({'a':a,'b':z,'net':net,'layer':layer,'w':width})
    print('net',net,'layer',layer,'complete',flush=True)
stats.update(after_segments=len(result),after_length_mm=sum(math.dist(t['a'],t['b']) for t in result),vias_retained=len(G['vias']))
(R/'validation/optimized-tracks.json').write_text(json.dumps(result))
(R/'validation/routing-cleanup.json').write_text(json.dumps(stats,indent=2));print(stats)
