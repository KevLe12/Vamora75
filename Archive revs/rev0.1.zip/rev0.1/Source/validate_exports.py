import json
from pathlib import Path
import cadquery as cq
import vtk
R=Path(__file__).resolve().parents[1];expected=json.loads((R/'validation/mechanical.json').read_text());checks={}
for name in ['case_bottom','case_top','plate_FR4_1p5mm']:
    s=cq.importers.importStep(str(R/'Mechanical'/(name+'.step'))).val()
    assert s.isValid() and len(s.Solids())==1
    assert abs(s.Volume()-expected[name]['volume_mm3'])<.01
    reader=vtk.vtkSTLReader();reader.SetFileName(str(R/'Mechanical'/(name+'.stl')));reader.Update()
    edges=vtk.vtkFeatureEdges();edges.SetInputConnection(reader.GetOutputPort());edges.BoundaryEdgesOn();edges.NonManifoldEdgesOn();edges.FeatureEdgesOff();edges.ManifoldEdgesOff();edges.Update()
    assert edges.GetOutput().GetNumberOfCells()==0
    checks[name]={'STEP_valid_solid':True,'STEP_volume_matches':True,'STL_boundary_or_nonmanifold_edges':0}
(R/'validation/exported-mechanical.json').write_text(json.dumps(checks,indent=2));print(checks)
