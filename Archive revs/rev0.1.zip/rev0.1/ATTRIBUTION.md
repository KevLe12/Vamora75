# Attribution

Vamora75 combines geometry and electrical information from the two folders supplied by the user. Files in those folders were treated as reference data, not instructions overriding the user's request.

- **Keyboard75 / Keyboard75_Exploded_ANSI**, supplied local project: source of the 82-key layout, RP2040-Zero module approach, matrix pin mapping, hot-swap footprints, schematic and initial routed PCB. Original project notes are retained in `Reference/Keyboard75_README.md`. Changes: Vamora branding and poem, trace cleanup, schematic grid and parity corrections, new case/plate fit, firmware packaging and validation.
- **Aster75**, supplied local project: source of the two-piece gasket-case construction method. The original generator is retained under `Reference`. All Vamora75 dimensions, plate coordinates, controller clearance, USB access, screw positions and underside engraving were rebuilt. Its source attribution is preserved in `Reference/Aster75_ATTRIBUTION.md`.
- Aster75 credits **The Manta75**, Eric Becourt (Rico / mymakercorner), hardware CC BY 4.0: https://github.com/mymakercorner/the_manta75 . The supplied license is retained in `Licenses`.
- MX socket reference: ai03's **MX_V2**, with supplied license in `Licenses/MX_V2_LICENSE.txt`: https://github.com/ai03-2725/MX_V2 . KiCad library notices are also retained.
- RP2040-Zero module documentation and drawings: https://www.waveshare.com/wiki/RP2040-Zero . Manufacturer names identify compatible parts; no endorsement is implied.
- CircuitPython runtime 10.3.1 is redistributed with its upstream license and source link in `Firmware/README.md`.
- QMK is GPL-licensed: https://github.com/qmk/qmk_firmware . The keyboard-level source is supplied as an alternative; the QMK runtime itself is not included.
- **Nam Quốc Sơn Hà** is a medieval public-domain poem, traditionally associated with Lý Thường Kiệt. The PCB uses the familiar Hán-Việt transcription, not a modern copyrighted translation. Text reference: https://vi.wikipedia.org/wiki/Nam_qu%E1%BB%91c_s%C6%A1n_h%C3%A0 . Authorship is historically debated.
- The geometric V/mountain and river logo and new Vamora75 scripts are original project additions. The logo is shared between PCB artwork and case engraving.

No new license is asserted over third-party input files beyond their supplied notices. Keep this attribution and the relevant notices when sharing the derivative project.
