# Vamora75 build guide — revision 0.1

## Parts

Use `Manufacturing/BOM.csv` as the purchasing checklist. Order a small PCB prototype run and print the case before committing to a finished build.

- Main PCB: 1.6 mm, two-layer FR4.
- Plate: **1.5 mm FR4**, not the main PCB's 1.6 mm thickness; ask the fabricator to confirm thickness tolerance and routed openings.
- 82 Kailh CPG151101S11 MX sockets; 82 1N4148W SOD-123 diodes.
- Original Waveshare RP2040-Zero module, 18 × 23.5 mm; no bare-MCU assembly required.
- Full-height MX switches and compatible ANSI keycaps. Required nonstandard sizes: 1.75u right Shift, 1u right modifiers; spacebar is 6.25u.
- Three 2u Cherry-compatible PCB stabilizers and one 6.25u stabilizer with 100 mm housing spacing. Use low-profile screw heads and insulating washers where needed.
- Twelve soft foam gasket strips, 24 × 5.5 × 2 mm, compressed to 1.6 mm nominally. Six tabs carry one strip above and below each tab.
- Case hardware and mounting details below.

## Mechanical datum and fit

All STEP/STL parts share the assembly coordinates. X runs left to right, Y toward the back, Z upward from the case underside. Main PCB is inset 12 mm from the case perimeter. Key coordinate CSV uses the PCB's rear-left corner and Y toward the front; the generator performs the coordinate conversion.

| Feature | Z, mm |
|---|---:|
| Floor upper surface | 3.0 |
| Conservative module component bottom | 6.0 |
| Module PCB lower / upper faces | 9.9 / 11.5 |
| Main PCB lower / upper faces | 15.0 / 16.6 |
| Plate lower / upper faces | 20.1 / 21.6 |
| Case split | 20.0 |
| Case top | 28.0 |

The plate upper face is 5.0 mm above the main PCB upper face. The PCB hangs from the switches; do not add rigid case standoffs to its six unused mounting holes. Support the board during switch insertion so hot-swap sockets do not lift.

Use straight soldered header pins with a **3.5 mm gap between the main PCB lower face and module PCB upper face**. Make a temporary spacer jig; do not assume ordinary plastic headers or sockets give this height. The 3.5 mm gap clears module-side solder joints, while its components and USB connector face the case bottom. Trim excess pin ends. Check the real module's button and connector heights against the envelope before soldering permanently.

The rear USB tunnel is 20 mm wide and 8.5 mm high, accommodating a plug reaching the recessed module connector. Use a slim USB-C data cable and confirm full seating on the prototype. The underside service opening exposes the module area for BOOT/RESET access. It is intentionally open; cover it with removable insulating tape if desired, without pressing either button.

Print the case bottom flat on its underside and the top flat on its split face. A printer must fit at least 359 × 154 mm; these parts do not fit a typical 220 mm bed. Suggested starting print settings: 0.2 mm layers, 4–5 walls, 30–40% infill. Use the native STEP files for modification. This case is designed as a printed prototype, not a fully specified CNC aluminum enclosure.

Eight 3.4 mm case clearance holes mate with 2.5 mm pilots in the top. Tap the pilots M3 carefully in the print. Use eight M3 button-head screws with head diameter ≤6 mm; select/cut screw length to **24 mm below the head** so the tip ends at Z=26 mm with 6 mm engagement and 1 mm blind-hole clearance. Start from M3×25 and shorten/deburr by 1 mm. Do not bottom screws out or overtighten. Use four adhesive 2 mm rubber feet; keep the controller service opening free.

The logo is recessed 0.6 mm into the 3 mm floor. No painted mark or sticker is required. Finished surface, color, switches and keycap profile are your choice; previews use simple keycap fit envelopes.

## Electrical assembly

1. Inspect Gerber and drill previews with the fabricator. Check socket model, PCB thickness and stabilizer hole spacing.
2. Solder the 82 bottom-side diodes. Diode **cathode stripe goes to pad 1 / ROW**; anode pad 2 goes to KEY_n. Use the native board to identify pads, rather than guessing orientation.
3. Solder all bottom hot-swap sockets. Keep pads flat; inspect bridges and cold joints.
4. Check resistance between VBUS_5V and GND, and between 3V3 and GND. Investigate a sustained near-short before applying USB power.
5. Fit the RP2040-Zero underneath using the 3.5 mm spacer jig. USB points to the rear at X=43.575 mm from the case left. Verify GP0 at module pad 1 and 5V at pad 23 against the manufacturer's pinout before soldering all pins.
6. Flash and test the bare board as described in `Firmware/README.md`. Briefly bridge each switch's two electrical contacts to test its matrix cell without installing all switches.
7. Install stabilizers first. Spacebar stabilizer drilling is reversed relative to Backspace, Enter and left Shift. Test wire movement before adding the plate.
8. Fit switches into the plate, align every switch pin, then press into sockets while supporting each socket underneath. Straighten bent pins; do not force them.
9. Apply the gasket strips to the plate tabs, put the assembly in the lower case, and verify USB and service access. Fit the top and tighten evenly just enough to close the split.
10. Add keycaps and feet. Test all keys, modifiers, Fn media keys, simultaneous chords, reconnect, reboot and sleep/wake on Windows. Check for scraping keycaps, stabilizer binding, case flex and cable strain.

## Release status

Native KiCad DRC/ERC and schematic parity reports are included, as are CAD intersection and firmware logic checks. They do not prove actual USB timing, solderability, switch clip retention, gasket feel, printer shrinkage, stabilizer brand compatibility, or long-term socket reliability. Record any prototype changes in the source and regenerate all affected deliverables together.
