# Vamora75 revision 0.1 verification

The final PCB passed KiCad 10.0.6 native DRC with zero violations, zero unconnected items and zero schematic parity issues. The schematic passed ERC with zero violations after inherited off-grid connections were corrected. The FR4 plate board passed outline DRC.

`project-checks.json` independently compares every schematic net's pin membership with the final PCB, checks all 82 matrix cells and the module mapping, verifies the 82 plate switch openings and validates the official RP2040 UF2 structure/family. `firmware.json` records the host key-report tests. `mechanical.json` records valid CAD solids and nominal intersection checks.

`routing-cleanup.json` records the change from 5,820 to 1,686 segments (217 vias retained). These are shorter/simpler trace chains on the supplied electrical topology, not a claim of an entirely new routing architecture. COL9 retains its original routing after a failed shortcut check.

**Not yet tested:** actual fabricated boards, power-on/USB enumeration, firmware execution on RP2040, QMK compilation, sleep/wake, real switch/stabilizer and plate fit, printed case tolerances, gasket compression behavior, and long-term reliability. Prototype before ordering a batch.

KiCad's stock ignored checks are listed in its JSON reports. No new exclusions were added to hide the detected crossings or off-grid warnings; those issues were corrected. Schematic module pins are represented as passive pins, so ERC cannot establish the correctness of its internal electronics. The carrier relies on a purchased original Waveshare module.
