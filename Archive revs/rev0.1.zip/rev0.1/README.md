# Vamora75

82-key Windows ANSI mechanical keyboard with an original Waveshare RP2040-Zero USB-C module, MX hot-swap sockets, a 1.5 mm FR4 gasket plate, and a two-piece custom case.

**Revision 0.1 — digitally checked, unbuilt prototype.** This is one coordinated design, not interchangeable parts from the two input folders. Physical assembly, USB operation, switch retention and typing feel still need a first prototype.

![Vamora75](Previews/assembled.png)

## Open and build

- Open `PCB/Vamora75.kicad_pro` in KiCad 10.0.6 or newer.
- Read `BUILD_GUIDE.md` before ordering or assembling.
- Use `Mechanical/Vamora75_assembly.step` for the complete mechanical assembly.
- Use `Manufacturing/main_gerbers.zip` for the main PCB and `Manufacturing/plate_gerbers.zip` for the FR4 plate, together with `Manufacturing/FABRICATION.md`.
- The complete CircuitPython flash package is in `Firmware/CircuitPython`; the alternative QMK source is in `Firmware/vamora75`. Follow `Firmware/README.md`.

## Design

| Item | Specification |
|---|---|
| Layout | 82 keys, US ANSI, Windows key, arrows, F1–F12, navigation column |
| Main PCB | 334.6125 × 129.825 mm, 1.6 mm FR4, 2 copper layers |
| Controller | Waveshare RP2040-Zero module, underneath PCB, components facing down |
| Switches | 82 full-height MX, 3-pin or 5-pin, 19.05 mm pitch |
| Sockets | 82 Kailh CPG151101S11 MX sockets, bottom mounted |
| Matrix | 7 × 12, 82 diodes, COL2ROW |
| Plate | 1.5 mm FR4; separate routed switch and stabilizer openings |
| Case | 358.6125 × 153.825 × 28 mm; printed PETG/ABS/ASA prototype |
| Mount | Six plate tabs, twelve 24 × 5.5 × 2 mm gaskets |
| Branding | V/mountain and river logo on PCB back and engraved case underside |
| Poem | Four-line Hán-Việt text of Nam Quốc Sơn Hà on PCB back silkscreen |

The Keyboard75 layout, hot-swap geometry, RP2040 module and matrix mapping form the electrical base. Aster75 supplied the approach for a parametric two-piece gasket case. Its ATmega controller, USB daughterboard, 83-key plate, case dimensions and firmware binary are not part of this build.

The PCB routing has been straightened with clearance checks; one net was restored after native DRC caught crossing shortcuts. The delivered board is checked again after that correction. Reports live in `validation/`; these are digital checks, not physical qualification.

See `ATTRIBUTION.md` for source credits and licenses. Original Downloads folders were not modified.
